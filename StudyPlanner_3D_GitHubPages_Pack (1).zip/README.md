# Study Planner — 3D Tools Model (GitHub Pages)

This folder is ready to host a 3D model viewer using Google's `<model-viewer>`.

## What you'll get
- A clean 3D viewer page (`docs/index.html`)
- A lightweight GLB model (`docs/study_planner_focusboard.glb`)

## Deploy in 60 seconds (GitHub Pages)
1) Create a new GitHub repo (public).
2) Upload everything from this zip **as-is** (keep the `docs/` folder).
3) Repo → **Settings** → **Pages**
4) Source: **Deploy from a branch**
5) Branch: **main** (or master) and Folder: **/docs**
6) Save → wait 30–60s → you'll get a link like:
   `https://<username>.github.io/<repo>/`

## Use in Framer
- Button link → paste the GitHub Pages URL.
- Or embed via iframe: `<iframe src="YOUR_URL" style="width:100%;height:600px;border:0;"></iframe>`
